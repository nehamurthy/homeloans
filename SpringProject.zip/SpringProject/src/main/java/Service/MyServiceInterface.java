package Service;

import com.model.Login;

public interface MyServiceInterface {
	 public User validateUser(User user);
}
