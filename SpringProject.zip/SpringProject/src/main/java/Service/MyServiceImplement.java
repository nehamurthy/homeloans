package Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MyDaoInterface;
import com.model.Login;

@Service("myService")
public class MyServiceImplement  implements MyServiceInterface{
	
	@Autowired
    MyDaoInterface mydao;

	 public User validateUser(User user) {
		    return mydao.validateUser(user);
		  }
}


