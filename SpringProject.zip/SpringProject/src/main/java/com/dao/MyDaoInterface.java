package com.dao;

import com.model.Login;

public interface MyDaoInterface {
	 User validateUser(User user);

}
