package com.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.model.Login;




@Repository("myDao")
public class MyDaoImplement implements MyDaoInterface {

 
		
		
		public User validateUser(User user) {
		    
		    EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
			EntityManager em = emf.createEntityManager();
			User f =null;
			try{
				f=(User)em.createQuery("SELECT f FROM User f WHERE f.username=:uname and f.password=:pwd")
			         .setParameter("uname", user.getUsername())
			         .setParameter("pwd",user.getPassword())
			         .getSingleResult();
			}
			catch(Exception e) {System.out.println(e); }
			em.close();
			System.out.println(f);
			return f;
		  }

}